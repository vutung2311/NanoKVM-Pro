#!/bin/bash

exec >/dev/null 2>&1

readonly RAMFS_ROOT="/dev/shm"
readonly APP_ROOT="/kvmcomm"

safe_rm() {
    target="$1"
    if [ -e "$target" ]; then
        if [ -d "$target" ]; then
            # Automatically add -r parameter to delete directory
            rm -rf "$target" || {
                exit 1
            }
        else
            # Regular file is deleted directly
            rm -f "$target" || {
                exit 1
            }
        fi
    fi
}

safe_copy() {
    local src=$1
    local dest=$2
    if [ ! -e "$src" ]; then
        exit 1
    fi
    cp -av "$src" "$dest" || exit 1
}

safe_rm "${RAMFS_ROOT}${APP_ROOT}"
safe_copy "${APP_ROOT}" "${RAMFS_ROOT}${APP_ROOT}"
